OPENSECRETS — VALIDATED 05:19:37Z SNAPSHOT, PARTIAL COVERAGE

Snapshot validated2026-10-02T05:19:37Z (October2,1:19a.m. Eastern). This archive contains all29CSV files and threeJSON products from that snapshot, plus reusable collector, requirements, scope registry, operating instructions and independent review evidence. All29CSV files matched the prior0458 independent audit hashes, and all51 copied source files matched before/copy/after. CHECKSUMS.json records this delivery's file hashes. Later RUN-owned export is separate; this archive deliberately preserves the checked snapshot available immediately.

The full requested dataset is NOT complete. Dollars are nominalUSD. Rows preserve source URLs, capture dates/times and hashes; source as-of differs from capture time. Missing values stay blank; signed net giving stays signed; partial sums do not become exact industry totals. Native export dates have date-only precision when the time is unknown.

Observed data
- Industry totals:72industry-cycle rows (36primaryF03/F05/F09/T2100,36comparison),2008–2024.
- Top contributors:1,418organization-cycle rows (698primary,720comparison); industry-page PAC/individual splits remain incomplete.
- NEW organization profile history:1,173numeric rows from83profiles;673rows2008–2024, all with PAC and individual amounts;500pre2008;zero2026. These are profile observations, not a historical industry census.
- Linked profile totals:296numeric/402blank across71profiles. Of numeric links,256differ from industry-page totals and40are equal with universe equivalence unproven. Do not replace industry-page components with these profile amounts.
- Current Mentat rosters:80names/eightworkbooks;22exact profile matches,38no organization rows,20no exact match. Only14roster rows have recovered history. Matching does not establish exhaustive historical membership.
- Annual lobbying spend:152numeric observations (76primary,76comparison),95blank. Native-export observations repeat sources and are not additive.
- Lobbying client spending:11,892numeric rows (5,277primary,6,615comparison),10blank placeholders. Not a unique-client count across years.
- Client/scope/year splits:7,338numeric rows,6,272reconciled and1,066partial (873component-sum mismatches,193scope mismatches). Primary5,004 (1,483banks,200credit unions,3,321broadinsurance),comparison2,334 (2,292M02,4B08,4B09,34F06). There are102partial annual scope-years andZEROcomplete industry in-house/outside aggregates.
- PAC recipients:9,861rows from139of3,300planned PAC/cycle pages;3,161missing in this historical snapshot. Overlapping memberships and Presidential/independent recipients retain their scope.
- National:69office/party observations containing138donor values;84derived aggregates;9election-cost cycles,2008–2024.

Material missing coverage
1. No usable2026 contribution/national observations: candidate responses served2024 and were rejected. Modern annual lobbying2026 coversJanuary–June,cutoffJune30,July23release/download note. Client split pages do not state source cutoff/release; exactT2100 cutoff is unknown. Capture date is not source as-of.
2. Industry individual/employee giving by party/chamber remains unobserved. Combined donor tables do not identify donor types separately. Industry PAC chamber cells have62partial sums andZEROcertified exact cells;3,161PAC/cycle pages are absent in this snapshot.
3. Company coverage is incomplete. Recovered profile history differs from industry-page universes; current Mentat rosters are not historical censuses. Numeric profile matches cannot silently fill industry totals or employee-only cells.
4. Complete industry in-house/outside lobbying totals remain absent. Annual exports provide spend; lobbyist counts are people, not clients or dollar splits. LegacyT2100 spend remains distinct from broaderM02; exactT2100 has no in-house/outside split here.
5. F09is broadinsurance,not P&C-only;T2100isAutoManufacturers;M02is broader comparison. Exact communitybank,crypto,fintech,fullMentattelecom and life-only aggregate mappings remain unverified in inspected sources. B08/B09/F06 retain comparison labels; no zero coverage or nonexistent source is inferred.

Validation and use
Existing reviewed CLI build1167.361seconds,58PASS/10INFO/0FAIL,8,265presentHTTP200cached bodies rehashed. Bounded independent CSV audit verified counts, arithmetic/status/year/key/group/provenance fields and stable hashes; no new independent raw-body audit or software-test run. Prior60-test software evidence remains historical. Open csv/ and review gaps.csv,gap_summary.csv,coverage_census.csv before aggregating. Detailed audit is review/REFRESHED_SNAPSHOT_0458_VERIFICATION.txt and _COUNTS.json.

Collector documentation is collector/README.md. Raw cache and active queue are outside this archive at C:/melange-data/forecast-redesign-20261001-review/standardized-collector. Do not duplicate the existing RUN, reset backoff or overwrite its export. External-machine path overrides are documented. The older013154and040315delivery folders/ZIPs remain unchanged. Newer captures/exports are not in this dated archive. Forecast scratch work is separate; candidate readiness remainsHOLD, with no production apply/publication or console restart.