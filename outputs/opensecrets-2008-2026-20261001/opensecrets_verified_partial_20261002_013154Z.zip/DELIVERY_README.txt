OPENSECRETS — EVERY CURRENTLY VALIDATED CSV, PARTIAL COVERAGE

Snapshot validated: 2026-10-02T01:31:54Z (October 1, 9:31 p.m. Eastern).
This archive contains every CSV in the standardized collector's validated export: 29 CSV files, including 23 data tables and six diagnostic/crosswalk products, plus three JSON products. It also contains the reusable Python collector, requirements, scope registry, operating instructions and dated review evidence. File bytes match the validated snapshot; CHECKSUMS.json records the delivery file hashes.

The full requested dataset is NOT complete. Source URLs, capture dates/times, source hashes, requested/served periods and published as-of qualifications remain in the CSV rows. Dollars are nominal USD; missing values remain blank; signed net amounts remain signed. Partial sums are explicitly partial and must not be used as complete industry totals. Native-export capture dates have date-only precision when the time was not recorded. The frozen export is delivered immediately while the original collector continues gathering later pages into its existing cache.

Observed data in this delivery
- 72 industry-cycle totals: 36 primary F03/F05/F09/T2100 and 36 comparison, 2008-2024.
- 1,418 top-contributor organization-cycle rows, with component-source gaps retained.
- 114 annual lobbying scope-year spend observations: 76 primary, 38 comparison. The native-export table repeats sources and is not additive.
- 7,569 client spending rows, excluding 67 blank placeholders.
- 3,083 client/scope/year split rows: 2,625 reconciled, 458 partial (391 component-sum mismatches, 67 industry-scope mismatches). These are not 3,083 distinct clients. Zero complete industry in-house/outside aggregates; 55 industry-year rows have partial coverage.
- 9,861 PAC recipient rows from 139 observed PAC/cycle pages out of 3,300 planned. PAC membership overlaps and Presidential/independent recipients must be respected.
- 69 national office/party rows containing 138 donor values; 84 derived national aggregates; nine election-cost cycles, 2008-2024.
- 80 current Mentat roster names across eight workbooks, with no verified profile matches. Current top-ten rosters are not historical industry censuses.

Material missing coverage
1. 2026 contribution/national pages do not provide usable2026 observations here: candidate responses served2024, which was rejected; election-cost history ends2024. Modern annual lobbying2026 covers January-June, cutoff2026-06-30, with a July23 release/download note. Client pages do not state a cutoff/release date; exactT2100 cutoff is unknown. Capture date is not source as-of.
2. Industry individual/employee giving by party/chamber remains unobserved. Combined PAC+individual candidate tables do not identify donor types separately. Industry PAC chamber totals have62 partial cells and zero certified exact cells;3,161 PAC/cycle pages remain missing in this snapshot.
3. Industry top-contributor PAC/individual splits are incomplete. The nine observed requested-window organization-profile records are BankofAmerica2008-2024; documented profile-versus-industry universe differences remain. Organization profile totals and current roster lists cannot substitute for complete historical industry data.
4. Complete industry in-house/outside lobbying totals are absent. Supplemental annual exports supply spend only; Lobbyists is a headcount, not clients. ExactT2100 legacy spend is separate from broader modernM02, and has no source in-house/outside split here.
5. F09 is broad insurance, not P&C-only. T2100 is AutoManufacturers; M02 is a broader comparison. Exact aggregate mappings for communitybanks,crypto,fintech,the fullMentattelecomroster and life-onlyinsurance were not verified in inspected sources; that is not proof none exists. B08/B09/F06 remain separately labeled comparisons.

Validation
Existing reviewed CLI build:85.301seconds,58PASS/10INFO/0FAIL,3,628 presentHTTP200cached bodies rehashed. Bounded independent CSV review found no arithmetic, flag, year, key, group-count or populated-provenance-field errors; export hashes remained stable. This is separate from an independent raw-page audit and does not prove complete coverage. Software code remains unchanged from the preceding60-test pass.

Use
Open csv/ for the tables; inspect gaps.csv, gap_summary.csv and coverage_census.csv before aggregating. Collector instructions are collector/README.md; the existing working package remains C:/Users/pgoff/Mentat/outputs/opensecrets-2008-2026-20261001/standardized. Raw cache/state are outside this archive under C:/melange-data/forecast-redesign-20261001-review/standardized-collector. Do not launch a duplicate against that active cache, restart PID68360, or reset its backoff. An offline rebuild against the existing cache uses the reviewed CLI: python -m osc build. External-machine path overrides are documented; this archive does not contain the live raw cache or queue.

The forecast handoff audit and scratch apply/rollback package are complete separately. Candidate readiness remains HOLD. No production apply/publication, console restart, model variant or owner waiver occurred.
