PARTIAL OPENSECRETS SNAPSHOT — PAC AGGREGATES REMAIN UNVERIFIED

This is the dated offline export validated2026-10-02T09:42:32Z, with its formal CLI receipt generated09:43:13Z. The frozen source is C:/melange-data/forecast-redesign-20261001-review/standardized-collector/snapshot-20261002T093258Z. It is an additional partial research dataset, not complete coverage of the requested industries, cycles, companies or measures. Individual rows retain their own source URLs and capture dates; export validation time is not the date every source was captured.

IMPORTANT QUARANTINE / OVERRIDE
The three files below are preserved unchanged ONLY in unverified_pac_tables/:
  pac_pages.csv
  pac_chamber_party.csv
  pac_candidate_giving_industry.csv
Their money, complete/exact flags and reconciliation assertions are not certified. Existing extraction can prefer source D/R summaries and combine them with detailed Other/Unclassified amounts even where the source contradicts itself. This can double-count or conceal party-label conflicts. More successfully acquired pages do not repair this rule. Do not use these derived fields as verified model targets or interpret formal validation PASS as proof of exact PAC totals.

pac_recipients.csv preserves the captured detail literally. This does not establish that conflicting source party labels are correct. No party or amount has been silently corrected; no balancing zero has been invented. Historical conflict evidence is in historical_conflict_evidence/, explicitly from the prior06:19:59Z snapshot. Its55page/62cell counts are not current snapshot counts. Chrysler2008 and U.S.Telecom2008 examples and repair requirements remain applicable evidence of the unrepaired rule.

This README and OPERATOR_RECEIPT.txt override generic certification wording in raw_cli_receipt/UNVERIFIED_RECEIPT.md and raw_cli_receipt/receipt.json. Those raw files are byte-preserved software outputs, not an independent audit. Their blanket statements about complete/exact aggregates and their generic all-tier resume/rate-limit language must not be treated as this delivery's instructions or factual conclusions. The final predecessor queue was deadline-deferred; it was not evidence that every remaining page was bot-blocked. Formal checks and tests do not cover the known PAC source-conflict defect.

HOW TO READ COVERAGE
Network successes, unique requested URLs, planned queue entries, parsed PAC pages, detailed recipient rows and industry cells have different denominators. Unavailable placeholder rows are not observations. Read extraction_status, completeness_status, amount_status and reason_code with each value. Keep exact amount_usd distinct from explicitly labeled partial_sum_usd; all three quarantined tables remain uncertified regardless of those labels. See the bounded current review and operator receipt for this snapshot's counts and verification limits.

Amounts are nominal USD and preserve signed net refunds. Blank means missing/unavailable, not zero. Source capture, reporting cutoff, platform/FEC release and export validation date are distinct. Dates are blank where the page did not state them. Continued acquisition after this export is outside this immutable archive.

REQUESTED COVERAGE STILL MISSING OR LIMITED
- Industry individual candidate giving by party/chamber has no verified aggregate observations in the inspected route. Its blank reason-coded cells are not zero employee giving. Published individual categories are not certified employee-only. Combined candidate lists or national totals cannot be subtracted across unmatched universes to invent these cells.
- Campaign/national2026 observations were unavailable in the inspected source captures; a2026 request served as2024 is rejected, not relabeled. Modern annual lobbying2026 covers January–June where the source supports it (June30 cutoff, July23 release). Client pages may not state their own cutoff/release; those fields remain blank. Exact legacyT2100 cutoff is unknown.
- F09 is broad insurance, not verified P&C-only. M02 Automotive is a broader comparison to T2100 manufacturers, not its substitute. B08/B09 provide partial telecom comparisons; F06 is broad finance, not fintech. Exact community-bank, crypto, fintech, full Mentat telecom and life-only aggregate mappings have not been verified in the inspected sources. This is not proof no such taxonomy exists.
- Current PAC/organization rosters and80current company names are not historical industry censuses. Organization profiles can include affiliates or wider scopes; exact-name matches and equal dollar amounts do not prove universe equivalence. Top contributors can lack PAC/individual component splits.
- Partial client in-house/outside components do not establish complete industry splits. Lobbying and contributions are separate accounts; lobbying is not partisan giving and must not be added to campaign contributions.

FORECAST / OPERATIONS
This source snapshot claims no>=90percent forecast accuracy. SenateG6 and dependence HOLDs remain separate. No model, forecast default, production pointer or console was changed/published for this delivery. The independent source collector continues under separate root ownership; this archive does not update itself. The four earlier dated folders/ZIPs013154,040315,051937,061959terminal are preserved.

LAYOUT
csv/: ordinary source-derived CSVs and formal validation/taxonomy JSON; still subject to scope/missingness limitations.
unverified_pac_tables/: the three unsafe derived PAC tables, unchanged.
raw_cli_receipt/: byte-preserved generic receipt, explicitly overridden above.
export_evidence/: dated export/receipt logs, source snapshot limitations and ownership/readiness records.
historical_conflict_evidence/: prior snapshot's conflict reports, not a new full re-aggregation.
current_review/: bounded current verification evidence, added only after review READY.
SOURCE_COPY_HASHES.csv and supplemental copy records: source-before/staged/source-after hashes.
CHECKSUMS.csv: staged file inventory and SHA256; see OPERATOR_RECEIPT.txt for ZIP verification limits.
