PARTIAL SOURCE DATA — KNOWN PAC AGGREGATE CONFLICTS
TERMINAL RUN SNAPSHOT: 2026-10-02T06:19:59Z

The bounded collection run has ended with 3,029 PAC/cycle URLs deferred. The requested dataset is NOT complete. Automated validation reports 58 PASS / 10 INFO / 0 FAIL, but does NOT detect the PAC source-summary/detail conflicts found by independent review. Four T2100/2008 exact flags are NOT CERTIFIED. Collector code has not been repaired.

READ THIS BEFORE AGGREGATING PAC DATA
Three unchanged export tables have been moved into unverified_pac_tables/:
- pac_pages.csv: all_party_sum_usd and related reconciliation labels are unverified when summary classifications conflict with recipient detail.
- pac_chamber_party.csv: selected summary amounts conflict with recipient sums in 62 cells across 56 PAC/cycles.
- pac_candidate_giving_industry.csv: its four exact flags, all T2100/2008, are quarantined. House R summary440,750 versus recipient detail438,750 differs2,000; the other three arithmetic matches do not certify a consistent industry-year universe.

There are 55 page-level all-party discrepancies. Summary D/R plus detail Other/Unclassified can double count a source-label disagreement; a separate Presidential source inconsistency also exists. Do not silently relabel parties or correct source amounts. pac_recipients.csv remains in csv/ as faithfully captured detail, not a guarantee that conflicting source party labels are correct. Review FINAL_PAC_PAGE_DISCREPANCIES.csv, FINAL_PAC_CHAMBER_DISCREPANCIES.csv and FINAL_SNAPSHOT_VERIFICATION.txt in review/. The original gaps/crosschecks may refer to filenames now in unverified_pac_tables/; those CSV bytes and references were preserved. Future collector repair must gate exact eligibility on source-summary/detail agreement and all-party reconciliation.

CONTENTS AND VERIFIED COPY
All 29 original export CSVs are included: 26 in csv/, three in unverified_pac_tables/. Three export JSON files accompany them. Review adds two discrepancy CSVs, the final count/hash report, independent findings, forecast review and a copy of the forecast package README. Reusable collector, requirements and scopes are included. All 29 export CSVs match the final independent audit hashes; all 54 copied files matched before/copy/after. CHECKSUMS.json binds delivery files. Raw cache/queue are not in this archive.

OBSERVED DATA, DISTINCT FROM PLACEHOLDERS
- Industry totals: 72 observations, 36 primary and 36 comparison, 2008–2024. Top contributors: 1,418 observations, 698 primary and 720 comparison.
- Company profile history: 1,877 numeric rows from 132 profiles; 1,088 requested-window rows2008–2024 all with PAC and individual amounts, 789 earlier rows, no2026. Linked profile totals489numeric/209blank across118profiles;415differ from industry-page totals and74equal amounts have unproven universe equivalence. Profile amounts are not automatically industry-total components.
- Current Mentat rosters:80names/eightworkbooks;22exact matches with history,38no organization rows,20no exact match. These are current roster/profile observations, not historical membership censuses.
- PAC detail:271observed pages/3,029deferred of3,300planned;13,918recipient rows, including89signed negative rows. Industry table has60partial cells and4quarantined exact flags; no unqualified exact-industry certification. Industry individual/employee candidate amounts remain unavailable.
- Annual lobbying spend:152numeric observations (76primary,76comparison),95blank. Client spend:11,892numeric rows (5,277primary,6,615comparison),10blank. Neither is a unique-client census across years; repeated native sources are not additive.
- Client/scope/year splits:7,338numeric observations,6,272reconciled and1,066partial (873component-sum/193scope discrepancies). Primary5,004 (1,483banks,200credit unions,3,321broad insurance);comparison2,334 (2,292M02,4B08,4B09,34F06). There are102partial annual scope-years and ZERO complete industry in-house/outside aggregates.
- National:69office/party rows containing138donor values;84derived aggregates,9election-cost cycles. Derived rows are not new source observations.

REMAINING SCOPE LIMITS
No usable2026 contribution/national observations were recovered; fallback2024 was rejected. Modern annual lobbying2026 coversJanuary–June,cutoffJune30,July23release/download note. Client split pages do not state cutoff/release dates; exactT2100 cutoff remains unknown. Capture time is not source as-of. Published individual categories are not certified employee-only. F09is broadinsurance,not P&C-only;T2100isAutoManufacturers;M02is broader comparison. Exact communitybank,crypto,fintech,fullMentattelecom and life-only aggregates remain unverified in inspected sources. Missing values stay blank; signed net amounts stay signed; nominalUSD is preserved. Source URL/capture/hash fields and source-specific date precision remain in rows.

EVIDENCE AND COMPLETION BOUNDARY
Formal validation rehashed8,442cached bodies. Independent final checks bound CSV counts/status/periods/arithmetic/provenance and stable hashes; two targeted raw examples diagnosed the PAC conflicts. This is not a comprehensive new source audit or proof of complete coverage. Prior60software-test evidence is historical and misses the new certification gap. RUN68360 released ownership06:20:00Z and was confirmed absent06:20:41Z. No automatic restart; deferred queue/cache preserved.

Collector instructions: collector/README.md. Working package: C:/Users/pgoff/Mentat/outputs/opensecrets-2008-2026-20261001/standardized. Raw cache/state: C:/melange-data/forecast-redesign-20261001-review/standardized-collector. Do not treat running the unchanged collector as a repair for the known eligibility defect.

Forecast review: review/REVIEW_AND_COMPLETION_2026-10-01.txt, also C:/melange-data/forecast-redesign-20261001-review/REVIEW_AND_COMPLETION_2026-10-01.txt. Scratch apply-package instructions: review/FORECAST_APPLY_PACKAGE_README.md; complete package remains C:/melange-data/forecast-redesign-20261001-review/forecast-completion/package/README.md and apply_forecast_completion.py. These references do not apply anything. Candidate readiness remains HOLD; production, published model pointer, owner choices and consoles unchanged.

The earlier013154,040315and051937folders/ZIPs remain frozen historical partial deliveries. This new archive does not overwrite them. Completion means the bounded run and review/delivery have finished; it does not mean every requested value was acquired or the known collector issue fixed.