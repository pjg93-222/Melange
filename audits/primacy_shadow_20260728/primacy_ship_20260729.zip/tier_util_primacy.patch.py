# -*- coding: utf-8 -*-
"""PATCH SPEC for fec/tier_util.py — primacy tier + graduated conduct ladder.

`tier_util` is already documented as "DISPLAY-ONLY … writes nothing, touches no engine", and
`moneyball_core.overall_display_tier()` already reads `Tier 1 => Champion`. So gating and
re-scoring the tier changes the Champion crown for free, with ZERO rank delta.

WHAT CHANGED FROM THE 2026-07-28 DRAFT
--------------------------------------
The first draft consumed only `severity >= 3` and produced a single binary verdict:
"ineligible for Tier 1." But the ledger schema ALREADY carries `leverage_mult` on every
event, and it was being collected and thrown away. Two problems followed from that:

  1. Barr and Hill received the identical consequence though their leverage differs
     (Hill: full-committee chair AND vehicle sponsor, 2.0. Barr: subcommittee chair of
     jurisdiction, 1.75). The ledger recorded the difference; the code erased it.
  2. Severity-2 events (MS-2026-003, credit appropriation) counted for nothing at all,
     so a member could accumulate an unbounded number of them at no cost.

The ladder fixes both by summing the ledger's own numbers instead of thresholding one field:

    effective_severity(member) = Σ  severity × leverage_mult   over OPEN, unexpired events

    eff >= 3  ->  tier ceiling 2      (cannot be a Champion)
    eff >= 6  ->  tier ceiling 3
    eff >= 9  ->  untiered

A ceiling is a FLOOR ON SLOT INDEX, not a fixed demotion: the member is barred from slots
above their ceiling's first slot and then re-enters at their own score position among the
remainder. A capped member with a weak score does not move at all. This is why French Hill
lands at slot 73 rather than "one tier down" — his score already put him there.

Current ledger:  Andy Barr 3×1.75 + 2×1.00 = 7.25 -> ceiling 3 (slot 12 -> 37)
                 French Hill 3×2.00        = 6.00 -> ceiling 3 (slot 73, unmoved)

Drop these functions into tier_util.py, then replace the body of
`legislative_press_tiers()` with the block at the bottom.
"""
import os, json

PRIMACY_PATH = 'primacy_factors.json'
LEDGER_PATH  = 'grievance_ledger.ndjson'

# (effective_severity threshold, tier ceiling). Descending; 0 == untiered. Ratified in the spec.
CONDUCT_LADDER = ((9.0, 0), (6.0, 3), (3.0, 2))
BUCKETS = (12, 36, 84)


def load_primacy_factors(root, path=None):
    """{member: factor_shrunk}. Missing file -> {} (FAIL OPEN: tier degrades to pure Leg%).
    Present-but-malformed -> raise (never treat corrupt evidence as absent)."""
    p = os.path.join(root, path or PRIMACY_PATH)
    if not os.path.exists(p):
        return {}
    try:
        doc = json.load(open(p, encoding='utf-8'))
        return {str(k): float(v['factor_shrunk']) for k, v in (doc.get('members') or {}).items()}
    except Exception as exc:
        raise ValueError('primacy_factors.json is present but invalid; refusing to treat '
                         'malformed primacy evidence as absent') from exc


def load_open_breaches(root, path=None):
    """{member: {'effective_severity': float, 'events': [(event_id, severity, mult)]}}.

    Sums severity x leverage_mult over OPEN events. Missing file -> {} (no gating).
    A missing `leverage_mult` defaults to 1.0 — the neutral multiplier, so an event logged
    without one still counts at face severity rather than vanishing."""
    p = os.path.join(root, path or LEDGER_PATH)
    out = {}
    if not os.path.exists(p):
        return out
    with open(p, encoding='utf-8') as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            ev = json.loads(line)
            if str(ev.get('status', 'open')) != 'open':
                continue
            sev = float(ev.get('severity', 0) or 0)
            if sev <= 0:
                continue
            mult = float(ev.get('leverage_mult', 1.0) or 1.0)
            rec = out.setdefault(str(ev.get('member')), {'effective_severity': 0.0, 'events': []})
            rec['effective_severity'] += sev * mult
            rec['events'].append((str(ev.get('event_id')), sev, mult))
    for rec in out.values():
        rec['effective_severity'] = round(rec['effective_severity'], 4)
    return out


def tier_ceiling(effective_severity, ladder=CONDUCT_LADDER):
    """Best tier a member may occupy. 1 = unconstrained, 0 = untiered. Monotone in severity."""
    for threshold, ceiling in ladder:
        if effective_severity >= threshold:
            return ceiling
    return 1


def _first_slot_of_tier(tier, buckets=BUCKETS):
    b1, b2, b3 = buckets
    return {1: 0, 2: b1, 3: b2}.get(tier, b3)


def primacy_scores(pcts, factors):
    """score = Leg% x primacy factor. Press weight is 0.00 in this policy.
    A member absent from `factors` keeps a neutral 1.0 (never silently zeroed)."""
    out = {}
    for member, values in (pcts or {}).items():
        try:
            leg = float(values['leg'])
        except (KeyError, TypeError, ValueError):
            continue
        out[member] = leg * float(factors.get(member, 1.0))
    return out


def apply_conduct_ladder(order, breaches, buckets=BUCKETS):
    """Re-seat `order` (best-first) honoring each member's conduct ceiling.

    Greedy and stable: walk the slots in order and take the best-scoring unplaced member
    permitted in that slot. Equivalent to giving each member a minimum slot index and
    otherwise preserving score order — so the ladder can only ever push a member DOWN,
    never up, and an uncapped member never loses a seat to a capped one.

    Returns (final_order, detail)."""
    floor = {}
    detail = {}
    for m in order:
        rec = breaches.get(m)
        if not rec:
            continue
        eff = float(rec['effective_severity'])
        ceil = tier_ceiling(eff)
        floor[m] = _first_slot_of_tier(ceil, buckets)
        detail[m] = {'effective_severity': eff, 'tier_ceiling': ceil,
                     'open_events': [e[0] for e in rec['events']]}
    if not floor:
        return list(order), detail
    remaining, final = list(order), []
    for slot in range(len(order)):
        for i, m in enumerate(remaining):
            if floor.get(m, 0) <= slot:
                final.append(remaining.pop(i))
                break
        else:
            break                       # everyone left is floored past the board; drop through
    final.extend(remaining)             # unreachable for buckets <= len(order); kept for totality
    return final, detail


# ---------------------------------------------------------------------------
# REPLACE the body of legislative_press_tiers() with:
#
#     root = root or _ROOT
#     with open(os.path.join(root, 'ranks_python.json'), encoding='utf-8') as handle:
#         rp = json.load(handle)
#     pcts = rp.get('pcts', {})
#
#     factors  = load_primacy_factors(root)          # {} -> fail open to pure Leg%
#     breaches = load_open_breaches(root)
#     all_scores = primacy_scores(pcts, factors)
#
#     rankable    = [m for m in members if m in all_scores]
#     score_order = sorted(rankable, key=lambda m: (-all_scores[m], m))   # deterministic tie-break
#     order       = apply_tier_overrides(score_order, load_tier_overrides(),
#                                        positions=load_tier_positions())
#
#     final, detail = apply_conduct_ladder(order, breaches)
#
#     b1, b2, b3 = BUCKETS
#     tier, tierrank = {}, {}
#     for i, m in enumerate(final):
#         tierrank[m] = i + 1
#         tier[m] = 1 if i < b1 else 2 if i < b2 else 3 if i < b3 else 0
#     return tier, tierrank, detail     # third value is NEW — callers render "not a Champion because…"
#                                       # keep a 2-tuple shim for one release.
# ---------------------------------------------------------------------------
